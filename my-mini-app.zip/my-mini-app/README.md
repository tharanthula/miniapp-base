# My Mini App (Base Build starter)

**What you do:**
1. Push this folder to a new GitHub repo.
2. Deploy to Vercel (New Project → Import → pick your repo).
3. After it deploys, copy your Vercel domain (e.g. `my-mini-app.vercel.app`).
4. Edit `app/layout.tsx` and `public/.well-known/farcaster.json`:
   - Replace `YOUR_VERCEL_URL` with your actual domain.
   - Commit/push.
5. Generate `accountAssociation` using Base Build's account tool and paste into `public/.well-known/farcaster.json` (replace header/payload/signature). Commit/push again.
6. In Vercel Project Settings → Deployment Protection, set Vercel Authentication to **Off**.
7. Share your URL in Base and tap **Open App**.

## Local dev
```bash
npm i
npm run dev
```

## Notes
- The app calls `sdk.actions.ready()` on mount so Base hides the splash screen.
- The `fc:miniapp` meta tag in `app/layout.tsx` powers the embed + Launch button.
- Replace the placeholder images in `/public` whenever you like.
