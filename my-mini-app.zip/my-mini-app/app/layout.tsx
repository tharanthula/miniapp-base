export const metadata = {
  title: "My Mini App",
  description: "Hello Base Build",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Replace YOUR_VERCEL_URL after first deploy
  const embed = JSON.stringify({
    version: "next",
    imageUrl: "https://YOUR_VERCEL_URL/og.png",
    button: {
      title: "Open App",
      action: {
        type: "launch_miniapp",
        name: "My Mini App",
        url: "https://YOUR_VERCEL_URL"
      }
    }
  });

  return (
    <html lang="en">
      <head>
        <meta name="fc:miniapp" content={embed} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body style={{ margin: 0, fontFamily: "system-ui, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
