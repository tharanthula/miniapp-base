"use client";

import { useEffect, useState } from "react";
import { sdk } from "@farcaster/miniapp-sdk";

export default function Page() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await sdk.actions.ready();
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!ready) return null;

  return (
    <main style={{ padding: 24 }}>
      <h1 style={{ margin: 0 }}>My Mini App 👋</h1>
      <p style={{ opacity: 0.8 }}>
        If you can read this, <code>ready()</code> worked.
      </p>
      <a href="https://docs.base.org/mini-apps/" target="_blank" rel="noreferrer">
        Base Mini Apps Docs
      </a>
    </main>
  );
}
